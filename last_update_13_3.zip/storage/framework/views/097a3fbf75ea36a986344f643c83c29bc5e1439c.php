<?php $__env->startSection('content'); ?>

    <section class="cart">
        <!-- start internal-page -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="container">
            <div class="title">بيانات الطلب رقم <?php echo e($order->id); ?></div>
            <div class="row">
                <!-- cart products -->
                <div class="col-lg-8">
                    <!-- cart product -->
                    <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product">
                        <div class="product-img">
                            <img class="mr-5 mt-14" loading="lazy" alt="صورة المنتج"   src="<?php echo e($orderItem?->product?->getFirstMediaUrl('master_image')); ?>">
                        </div>
                        <div class="product-title">
                            <h4 class="title"><a target="_blank" href="<?php echo e(route('products',$orderItem->product_id)); ?>"><?php echo e($orderItem?->product?->name); ?></a></h4>
                            <div class="product-price"><span><?php echo e($orderItem->price_discount?:$orderItem->price); ?></span> ريال سعودى</div>
                        </div>
                        <div class="product-count">
                            الكمية : <?php echo e($orderItem->quantity); ?>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <div class="row btn-rows">


                        <?php if($order->status == 'pending'): ?>
                            <?php echo $__env->make('website.orders.actions.refuse-order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                        <?php if($order->status == 'pending' && auth()->user()->type === 'vendor'): ?>
                            <?php echo $__env->make('website.orders.actions.accepted-order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>

                        <?php if($order->status == 'accepted' && auth()->user()->type === 'vendor'): ?>
                            <?php echo $__env->make('website.orders.actions.finish-order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endif; ?>


                        <div class="col-lg-6">
                            <a style="background-color: #a5eb6c;margin: 1%" class="btn btn-gray" href="<?php echo e(route('orders.index')); ?>">رجوع</a>
                        </div>
                    </div>


                </div>
                <div class="col-lg-4">
                    <div class="box">
                        <ul class="orders-list">
                            <li>
                                <span>رقم الطلب</span>
                                <span><a href="#"><?php echo e($order->id); ?></a></span>
                            </li>
                            <li>
                                <span>إسم المستخدم</span>
                                <span><?php echo e($order->user?->name); ?></span>
                            </li>
                            <li>
                                <span>إسم البائع</span>
                                <span><?php echo e($order->vendor?->name); ?></span>
                            </li>
                            <li>
                                <span>تاريخ الطلب</span>
                                <span><?php echo e($order->created_at?->format('Y-m-d')); ?></span>
                            </li>
                            <li>
                                <span>وقت الطلب</span>
                                <span><?php echo e($order->created_at?->diffForHumans()); ?></span>
                            </li>
                            <li>
                                <span>عدد المنتج</span>
                                <span><?php echo e($order->orderItems?->count()); ?></span>
                            </li>
                            <li>
                                <span>حالة الطلب</span>
                                <span><?php echo e($order->status_translate); ?></span>
                            </li>
                            <li>
                                <span>تقييم </span>
                                <span>
                  <div class="stars">
                    <span class="total">4.35 </span>
                    <i class="fas fa-star yellow"></i>
                    <i class="fas fa-star yellow"></i>
                    <i class="fas fa-star yellow"></i>
                    <i class="fas fa-star yellow"></i>
                    <i class="fas fa-star"></i>
                  </div>
                </span>
                            </li>
                        </ul>
                    </div>
                    <div class="box cart-orders">
                        <h5 class="title">تفاصيل العملية</h5>
                        <ul class="cart-orders-list">
                            <li>
                                <span>رقم العملية</span>
                                <span><?php echo e($order->id); ?></span>
                            </li>
                            <li>
                                <span>وقت العملية</span>
                                <span><?php echo e($order->created_at?->format('Y/m/d')); ?></span>
                            </li>
                        </ul>
                        <ul class="cart-orders-list">
                            <li>
                                <span>كوبون الخصم</span>
                                <span><?php echo e($order?->promoCode?->code ?? '-----'); ?></span>
                            </li>
                        </ul>
                        <ul class="cart-orders-list">
                            <li>
                                <span>الشحن</span>
                                <span class="product-price"><span><?php echo e($order->shipping_price); ?></span> ريال سعودى</span>
                            </li>
                        </ul>
                        <ul class="cart-orders-list">
                            <li>
                <span>
                  الإجمالي
                  <small>شامل الضريبة المضافة</small>
                </span>
                                <span class="product-price total"><span><?php echo e($order->total_price); ?></span> ريال سعودى</span>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- end internal-page -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/orders/show.blade.php ENDPATH**/ ?>