

<?php $__currentLoopData = $categoriesHaveProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<section>
        <div class="container">
            <a href="#">
                <img src="<?php echo e(asset('website/templates/images/adimg2.jpg')); ?>">
            </a>
        </div>
</section>

<section>
    <div class="container">

        <div class="row">
            <div class="sec-title">
                <h3 class="title">أحدث المنتجات في القسم <?php echo e($category->name); ?></h3>
                <a class="more" href="<?php echo e(route('categories',$category->id)); ?>">
                    مشاهدة الكل
                    <i class="fas fa-angle-double-left"></i>
                </a>
            </div>
        </div>
        <div class="row products">
            <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $child->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="col-lg-2">
                    <div class="product">
                    <a class="wishlist add-product-to-favorite" data-id="<?php echo e($product->id); ?>" href="#">
                        <i class="fas fa-heart favorite-product-<?php echo e($product->id); ?>"></i>
                    </a>
                    <div class="product-img">
                        <img loading="lazy"  src="<?php echo e($product->getFirstMediaUrl('master_image')); ?>" alt="<?php echo e($product->name); ?>">
                    </div>
                    <div class="product-content">
                        <h4 class="product-title"><a href="<?php echo e(route('products',$product->id)); ?>"><?php echo e($product->name); ?></a></h4>
                        <div class="product-price"><span><?php echo e($product->price); ?></span> ر.س</div>

                        <div class="stars">
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="product-color">
                            <span class="product-black"></span>
                            <span class="product-red"></span>
                            <span class="product-blue"></span>
                            <span class="product-yelow"></span>
                            <span class="product-white"></span>
                        </div>
                    </div>
                    <a class="product-basket add-to-cart" data-id="<?php echo e($product->id); ?>"  href="#">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/sections/filter-categories-have-products.blade.php ENDPATH**/ ?>