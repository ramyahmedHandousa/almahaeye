<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link type="text/css" rel="stylesheet" href="<?php echo e(asset('website/templates/css/image-uploader.min.css')); ?>">

    <style>

        .hidden-category{
            visibility: hidden !important;
        }


    </style>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="sec-title" style="margin-top: 20px;">
            <h2 class="title">أضف منتج جديد</h2>
        </div>
        <!-- form -->

        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="row">
            <form class="col-12" method="POST" action="<?php echo e(route('vendor-products.store')); ?>"
                  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- add-product -->
                <div class="row add-product-content">
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 form-group">
                            <input required type="text" name="name:<?php echo e($value); ?>" class="form-control"
                                   placeholder="اسم المنتج باللغة - <?php echo e($value); ?> "
                                   value="<?php echo e(old('name:'.$locale)); ?>"
                            >
                            <?php $__errorArgs = ['name:'.$value];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 form-group">
                        <select class="form-select" id="mainCategory" name="main_category_id">
                            <option value="">القسم الرئيسى</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(old('main_category_id') == $category->id ? 'selected="selected"' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['main_category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-lg-3 form-group">
                        <select name="category_id" id="subCategory" class="form-select">
                            <option value="">اختر القسم الفرعى</option>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="col-lg-3 form-group">
                        <select name="product_type_id" id="product_type_id" class="form-control">
                            <option value="">نوع النظارة</option>
                            <?php $__currentLoopData = $product_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>" <?php echo e(old('product_type_id') == $type->id ? 'selected' : ''); ?>><?php echo e($type->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-3 form-group">
                        <select class="form-select" name="brand_id">
                            <option value=""> ماركة النظارة</option>
                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($brand->id); ?>" <?php echo e(old('brand_id') == $brand->id ? 'selected' : null); ?>><?php echo e($brand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-6 form-group">
                        <label for="frame_color_id">لون الإطار</label>
                        <select class="frame-color form-select form-control select2" style="width:100% !important; direction: rtl !important;" multiple="multiple" name="frame_color_id[]">

                            <?php $__currentLoopData = $framesColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($frame->id); ?>" <?php echo e(is_array(old('frame_color_id')) && in_array($frame->id, old('frame_color_id')) ? 'selected' : ''); ?>>
                                    <?php echo e($frame->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-6 form-group">
                        <label for="frame_color_id">لون العدسة</label>
                        <select class="frame-color form-select form-control select2" style="width:100% !important; direction: rtl !important;" multiple="multiple" name="lens_color_id[]">
                            <?php $__currentLoopData = $lensColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>" <?php echo e(is_array(old('lens_color_id')) && in_array($value->id, old('lens_color_id')) ? 'selected' : ''); ?>>
                                    <?php echo e($value->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-2 form-group">
                        <select class="form-select" name="frame_material_id">
                            <option value="">خامة الإطار</option>
                            <?php $__currentLoopData = $frame_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $frame): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($frame->id); ?>" <?php echo e(old('frame_id') == $frame->id ? 'selected' : ''); ?>><?php echo e($frame->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-lg-2 form-group">
                        <select class="form-select" name="frame_shap_id">
                            <option value="">شكل الإطار</option>
                            <?php $__currentLoopData = $frame_shaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shape): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($shape->id); ?>" <?php echo e(old('shape_id') == $shape->id ? 'selected' : ''); ?>><?php echo e($shape->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="col-lg-2 form-group">
                        <select class="form-select" name="age_id">
                            <option value="">السن</option>
                            <?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($age->id); ?>" <?php echo e(old('age_id') == $age->id ? 'selected' : ''); ?>><?php echo e($age->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>

                    <div class="col-lg-3 form-group">
                        <input required type="number" class="form-control" name="price" placeholder="السعر"
                               value="<?php echo e(old('price')); ?>" step="0.01" min="0" max="1000">
                    </div>

                    <div class="col-lg-3 form-group">
                        <input required type="number" name="quantity" class="form-control" placeholder="الكميه"
                               value="<?php echo e(old('quantity')); ?>" min="0" max="1000">
                    </div>


                    <div class="col-lg-3 form-group">
                        <input required type="number" class="form-control" name="additional_data[frame_height]" placeholder="طول الاطار"
                               value="<?php echo e(old('additional_data.frame_height')); ?>" min="0" max="100">
                    </div>

                    <div class="col-lg-3 form-group">
                        <input required type="number" class="form-control" name="additional_data[temple_length]" placeholder="طول الزراع"
                              value="<?php echo e(old('additional_data.temple_length')); ?>" min="0" max="100">
                    </div>
                    <div class="col-lg-3 form-group">
                        <input required type="number" class="form-control" name="additional_data[lens_width]" placeholder="قطر العدسه"
                               value="<?php echo e(old('additional_data.lens_width')); ?>" min="0" max="1000">
                    </div>
                    <div class="col-lg-3 form-group">
                        <input required type="number" class="form-control" name="additional_data[nose_bridge]" placeholder="مقصوره العدسه"
                               value="<?php echo e(old('additional_data.nose_bridge')); ?>" min="0" max="100">
                    </div>


                    <?php $i = 1; ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-6 form-group">


                            <textarea name="description:<?php echo e($value); ?>"   class="form-control" placeholder="وصف المنتج باللغة - <?php echo e($value); ?> "
                                      id="" cols="30" rows="10"><?php echo e(old('description:'.$value)); ?></textarea>
                        </div>
                        <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <div class="col-12 form-group">
                        <div class="row">
                            <label class="col-lg-2"> صورة المنتج</label>
                            <div class="col">
                                <div class="upload-file form-group">
                                    <label>
                                        <div class="upload-icon">
                                            <img class="prev" loading="lazy"  src="<?php echo e(asset('website/templates/images/upload-to-cloud.png')); ?>">
                                        </div>
                                        <input  type="file" name="image" accept="image/*" id="file-input" class="inputfile" />
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-12 form-group">
                        <div class="row">
                            <label class="col-lg-2">صور اخرى للمنتج</label>
                            <div class="col">
                                <div class="input-images"></div>
                            </div>
                        </div>
                    </div>

                </div>


                <div class="row submit-row">
                    <div class="col-lg-3 order2">
                        <a class="btn btn-gray" href="<?php echo e(route('vendor-products.index')); ?>">الغاء</a>
                    </div>
                    <div class="col-lg-3">
                        <button type="submit" id="submitForm" class="btn">حفظ</button>
                    </div>
                </div>

            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="<?php echo e(asset('website/templates/js/code-rtl.js')); ?>"></script>

    <script type="text/javascript" src="<?php echo e(asset('website/templates/js/image-uploader.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('website/templates/js/categories.js')); ?>"></script>

    <script>

        $(document).ready(function() {
            $('.select2').select2();
        });

        $('.input-images').imageUploader();

        $(document).on('change', '.inputfile',  function () {

            if (this.files && this.files[0]) {
                var reader = new FileReader();
                reader.onload =  (e) => {
                    $(this).parent().find('.prev').attr('src', e.target.result).show();
                }
                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/vendor/products/create.blade.php ENDPATH**/ ?>