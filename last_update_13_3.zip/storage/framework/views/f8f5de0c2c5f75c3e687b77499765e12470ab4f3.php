<?php $__env->startSection('content'); ?>

    <!-- start slider -->
    <?php echo $__env->make('website.layouts.sections.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end slider -->
    <!-- start our Goal section -->
    <?php echo $__env->make('website.layouts.sections.our-goal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end section -->
    <!-- start categories section -->
    <?php echo $__env->make('website.layouts.sections.main-categories',['mainCategories' => $mainCategories ?? []], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end categories section -->
    <!-- start most order products -->
    <?php echo $__env->make('website.layouts.sections.products-most-order', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end products -->
    <!-- start Offers products -->
    <?php echo $__env->make('website.layouts.sections.offers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end products -->
    <?php echo $__env->make('website.layouts.sections.filter-categories-have-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- start banner -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/home.blade.php ENDPATH**/ ?>