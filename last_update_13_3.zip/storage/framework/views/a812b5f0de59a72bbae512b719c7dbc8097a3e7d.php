

<div class="row">
    <!-- box -->
    <?php $__currentLoopData = $refuseOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-4">
        <div class="box">
            <ul class="orders-list">
                <li>
                    <span>رقم الطلب</span>
                    <span><a target="_blank" href="<?php echo e(route('orders.show',$order->id)); ?>"><?php echo e($order->id); ?></a></span>
                </li>
                <li>
                    <span>تاريخ الطلب</span>
                    <span><?php echo e($order->created_at?->format('Y-m-d')); ?></span>
                </li>
                <li>
                    <span>وقت الطلب</span>
                    <span><?php echo e($order->created_at?->diffForHumans()); ?></span>
                </li>
                <li>
                    <span>عدد المنتج</span>
                    <span><?php echo e($order->order_items_count); ?></span>
                </li>
                <li>
                    <span>حالة الطلب</span>
                    <span><?php echo e($order->status_translate); ?></span>
                </li>
                <li>
                    <span>سبب الرفض</span>
                    <span><?php echo e(\Illuminate\Support\Str::limit($order->message,20,'...') ? : 'لايوجد '); ?></span>
                </li>
            </ul>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/orders/sections/refuse-orders.blade.php ENDPATH**/ ?>