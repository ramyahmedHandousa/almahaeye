
<div class="title cart-list-products"> عربية التسوق (<?php echo e(count($products)); ?>)</div>
<div class="col-lg-8 cart-list-products">
    <!-- cart product -->
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="product" id="cart-info-<?php echo e($product['id']); ?>">
            <div class="product-img">
                <img loading="lazy"  alt="<?php echo e($product['name']); ?>" class="mr-5 mt-14" src="<?php echo e($product['image']); ?>">
            </div>
            <div class="product-title">
                <h4 class="title"><a href="<?php echo e(route('products',$product['id'])); ?>" target="_blank"><?php echo e($product['name']); ?></a></h4>
                <div class="product-price">
                    <?php if($product['discount']): ?>

                        <span style="line-height: normal; text-decoration: line-through"><?php echo e($product['price']); ?></span>ر.س
                        <span><?php echo e($product['discount']); ?></span>ر.س
                    <?php else: ?>
                        <span><?php echo e($product['price']); ?></span>ر.س
                    <?php endif; ?>
                </div>
                
            </div>
            <div class="product-count">
                <div class="number">
                    <button class="value-button decreaseValue decrease" data-id="<?php echo e($product['id']); ?>"   value="Decrease Value"><i
                            class="fa fa-minus"></i></button>
                    <input type="number" id="quantity" class="form-control cartQuantity " data-price="<?php echo e($product['discount'] ?: $product['price']); ?>"  readonly value="<?php echo e($product['quantity']); ?>" min="1" max="50">
                    <button class="value-button increaseValue increase"  data-id="<?php echo e($product['id']); ?>"  value="Increase Value"><i
                            class="fa fa-plus"></i></button>
                </div>
            </div>
            <div class="product-delete">
                <a href="#" data-token="<?php echo e(csrf_token()); ?>" data-id="<?php echo e($product['id']); ?>" class="remove-from-cart"><i class="fas fa-trash"></i></a>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH /home/euindemo/public_html/resources/views/website/cart/sections/list-products.blade.php ENDPATH**/ ?>