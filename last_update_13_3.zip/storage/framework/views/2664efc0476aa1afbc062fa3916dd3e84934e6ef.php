<?php $__env->startSection('title', 'المستخدمين'); ?>
<?php $__env->startSection('styles'); ?>

    <style>
        .errorValidationReason{

            border: 1px solid red;

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->



    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title">طلبات التغير  </h4>
        </div>
    </div>


    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">

                <div class="dropdown pull-right">


                </div>

                <h4 class="header-title m-t-0 m-b-30">
                    
                </h4>

                <table id="datatable-fixed-header" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                    <tr>
                        <th>إسم التاجر</th>
                        <th> رقم هاتف التاجر</th>
                        <th>رقم الإيبان</th>
                        <th>رقم السجل التجاري</th>
                        <th>العنوان</th>
                        <th><?php echo app('translator')->get('trans.created_at'); ?></th>
                        <th><?php echo app('translator')->get('trans.options'); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $changes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->user?->name); ?></td>
                            <td><?php echo e($row->user?->phone ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->iban ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->commercial_registration	 ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->address ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->created_at != ''? @$row->created_at->format('Y/m/d'): "--"); ?></td>
                            <td>


                                <a href="#"
                                   onclick="acceptedOrRefuse(<?php echo e($row->id); ?>,'accepted')"
                                   data-href="<?php echo e(route('change_profile_status',$row->id)); ?>"
                                   data-toggle="tooltip" data-placement="top"
                                   data-original-title="موافقة"
                                   class="btn btn-icon btn-xs waves-effect  btn-success my-row-<?php echo e($row->id); ?>">
                                    <i class="fa fa-check"></i>
                                </a>
                                <a href="#"
                                   onclick="acceptedOrRefuse(<?php echo e($row->id); ?>,'refuse')"
                                   data-href="<?php echo e(route('change_profile_status',$row->id)); ?>"
                                   data-toggle="tooltip" data-placement="top"
                                   data-original-title="رفض"
                                   class="btn btn-icon btn-xs waves-effect  btn-danger my-row-<?php echo e($row->id); ?>">
                                    <i class="fa fa-ban" aria-hidden="true"></i>

                                </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div><!-- end col -->
    </div>
    <!-- end row -->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


    <script>


        function acceptedOrRefuse(id,status) {

            var href = $('.my-row-'+id).attr('data-href') + '?type='+status;

            console.log(href)
            swal({
                title: "هل انت متأكد؟",
                type: "success",
                showCancelButton: true,
                confirmButtonColor: "#DD6B55",
                confirmButtonText: "موافق",
                cancelButtonText: "إلغاء",
                confirmButtonClass: 'btn-danger waves-effect waves-light',
                closeOnConfirm: true,
                closeOnCancel: true,
            }, function (isConfirm) {
                if(isConfirm){
                    window.location = href
                }
            });

        }

        $(document).ready(function () {
            $('#datatable-responsive').DataTable( {
                "order": [[ 5, "desc" ]]
            } );

        });

    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/vendors/changes/index.blade.php ENDPATH**/ ?>