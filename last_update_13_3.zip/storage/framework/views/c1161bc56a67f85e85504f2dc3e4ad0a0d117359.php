<?php $__env->startSection('title' , 'إضافة مستخدم'); ?>

<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <style>

        .hidden-category{
            visibility: hidden !important;
        }


    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form id="myForm" method="POST" action="<?php echo e(route('products.store')); ?>" enctype="multipart/form-data" data-parsley-validate
          novalidate>
    <?php echo e(csrf_field()); ?>


    <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="btn-group pull-right m-t-15">
                    <button type="button" class="btn btn-custom  waves-effect waves-light"
                            onclick="window.history.back();return false;"> رجوع <span class="m-l-5"><i
                                class="fa fa-reply"></i></span>
                    </button>
                </div>
                <h4 class="page-title">إدارة المنتجات</h4>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <h4 class="header-title m-t-0 m-b-30">إضافة منتج</h4>

                    <div class="col-xs-6">
                        <div class="form-group<?php echo e($errors->has('name_ar') ? ' has-error' : ''); ?>">
                            <label for="name_ar">إسم*</label>
                            <input type="text" name="name_ar" value="<?php echo e(old('name_ar')); ?>" class="form-control"
                                   required placeholder="name_ar  ..." data-parsley-maxLength="225"
                                   data-parsley-maxLength-message=" name_ar  يجب أن يكون 225 حروف فقط" data-parsley-minLength="3"
                                   data-parsley-minLength-message=" name_ar  يجب أن يكون اكثر من 3 حروف "
                                   data-parsley-required-message="يجب ادخال  name_ar  "
                            />
                            <p class="help-block" id="error_name_ar"></p>
                        </div>
                    </div>


                    <div class="col-xs-6">
                        <div class="form-group<?php echo e($errors->has('name_en') ? ' has-error' : ''); ?>">
                            <label for="name_en">إسم بالإنجليزي*</label>
                            <input type="text" name="name_en" value="<?php echo e(old('name_en')); ?>" class="form-control"
                                   required placeholder="name_en  ..." data-parsley-maxLength="225"
                                   data-parsley-maxLength-message=" name_en  يجب أن يكون 225 حروف فقط" data-parsley-minLength="3"
                                   data-parsley-minLength-message=" name_en  يجب أن يكون اكثر من 3 حروف "
                                   data-parsley-required-message="يجب ادخال  name_en  "
                            />
                            <p class="help-block" id="error_name_en"></p>
                        </div>
                    </div>


                    <div class="col-xs-3">
                        <div class="form-group">
                            <label for="parent_id">  القسم الرئيسي*</label>
                            <select name="parent_id" id="" class="form-control category requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="form-group">
                            <label for="userName">  القسم الفرعي*</label>
                            <select name="category_id" id="" class="form-control sub_category requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-2">
                        <div class="form-group">
                            <label for="brand_id">الماركة</label>
                            <select name="brand_id" id="" class="form-control requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if(old('brand_id') == $value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-2">
                        <div class="form-group">
                            <label for="frame_material_id">خامات الإطار</label>
                            <select name="frame_material_id" id="" class="form-control requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $frame_materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if(old('frame_material_id') == $value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-2">
                        <div class="form-group">
                            <label for="age_id">السن  </label>
                            <select name="age_id" id="" class="form-control requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if(old('age_id') == $value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="frame_shap_id">أشكال الإطار</label>
                            <select name="frame_shap_id" id="" class="form-control requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $frame_shaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if(old('frame_shap_id') == $value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="product_type_id">أنواع النظارة</label>
                            <select name="product_type_id" id="" class="form-control requiredFieldWithMaxLenght" required>
                                <option value="" selected disabled=""> إختر  </option>
                                <?php $__currentLoopData = $product_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" <?php if(old('product_type_id') == $value->id): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="frame_color_id">لون الإطار</label>
                            <select name="frame_color_id[]" id="" class="form-control select2 requiredFieldWithMaxLenght" multiple required>
                                <?php $__currentLoopData = $framesColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>" ><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="lens_color_id">لون العدسة</label>
                            <select name="lens_color_id[]" id="" class="form-control select2 requiredFieldWithMaxLenght" multiple required>
                                <?php $__currentLoopData = $lensColors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($value->id); ?>"><?php echo e($value->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="frame_height"> طول الاطار*</label>
                            <input type="number" name="additional_data[frame_height]" value="<?php echo e(old('additional_data.frame_height')); ?>"
                                   class="form-control" placeholder=" طول الاطار.."
                                   
                                   data-parsley-min="0" data-parsley-min-message=" اقل رقم مسموح به 0"
                                   data-parsley-type="digits"data-parsley-type-message="طول الاطار لا تقبل الحروف ارقام فقط"
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message="طول الاطار  المنتج إلزامي"
                            />
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('frame_height')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('frame_height')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="userName"> طول الزراع*</label>
                            <input type="number" name="additional_data[temple_length]" value="<?php echo e(old('additional_data.temple_length')); ?>" class="form-control"

                                   
                                   placeholder=" طول الزراع.."
                                   
                                   data-parsley-min="0"
                                   data-parsley-min-message=" اقل رقم مسموح به 0"
                                   data-parsley-type="digits"
                                   data-parsley-type-message="طول الزراع لا تقبل الحروف ارقام فقط"
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message="طول الزراع  المنتج إلزامي"
                            />
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('temple_length')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('temple_length')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="userName"> قطر العدسه*</label>
                            <input type="number" name="additional_data[lens_width]" value="<?php echo e(old('additional_data.lens_width')); ?>" class="form-control"

                                   
                                   placeholder=" قطر العدسه.."
                                   
                                   data-parsley-min="0"
                                   data-parsley-min-message=" اقل رقم مسموح به 0"
                                   data-parsley-type="digits"
                                   data-parsley-type-message="قطر العدسه لا تقبل الحروف ارقام فقط"
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message="قطر العدسه  المنتج إلزامي"
                            />
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('lens_width')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('lens_width')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-sm-3">
                        <div class="form-group">
                            <label for="userName">  مقصوره العدسات*</label>
                            <input type="number" name="additional_data[nose_bridge]" value="<?php echo e(old('additional_data.nose_bridge')); ?>" class="form-control"

                                   
                                   placeholder=" مقصوره العدسات .."
                                   
                                   data-parsley-min="0"
                                   data-parsley-min-message=" اقل رقم مسموح به 0"
                                   data-parsley-type="digits"
                                   data-parsley-type-message=" مقصوره العدسات لا تقبل الحروف ارقام فقط"
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message="مقصوره العدسات للمنتج إلزامي"
                            />
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('nose_bridge')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('nose_bridge')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="price">(price)  سعر المنتج  *</label>
                            <input type="number" name="price"  min=0 oninput="validity.valid||(value='');"
                                   value="<?php echo e(old('price')); ?>"
                                   class="form-control requiredFieldWithMaxLenght" required>
                            <p class="help-block" id="error_price"></p>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="quantity">(quantity) الكمية المتوفرة من المنتج  *</label>
                            <input type="number" name="quantity" min=0 oninput="validity.valid||(value='');"
                                   value="<?php echo e(old('quantity')); ?>"
                                   class="form-control requiredFieldWithMaxLenght" required>
                            <p class="help-block" id="error_quantity"></p>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="userName"> وصف باللغة العربية</label>
                            <textarea type="text" name="description_ar" class="form-control m-input requiredFieldWithMaxLenght" required
                                      placeholder="إدخل  وصف عن  المنتج العربية   "   ><?php echo e(old('description_ar')); ?></textarea>
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('description_ar')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('description_ar')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="userName">   وصف باللغة الإنجليزية</label>
                            <textarea type="text" name="description_en" class="form-control m-input requiredFieldWithMaxLenght" required
                                      placeholder="إدخل  وصف عن  المنتج بالإنجليزي   "   ><?php echo e(old('description_en')); ?></textarea>
                            <p class="help-block" id="error_userName"></p>
                            <?php if($errors->has('description_en')): ?>
                                <p class="help-block">
                                    <?php echo e($errors->first('description_en')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="form-group text-right m-t-20">
                        <button id="hiddenButton" class="btn btn-primary waves-effect waves-light m-t-20" type="submit">
                            حفظ البيانات
                        </button>
                        <button onclick="window.history.back();return false;" type="reset"
                                class="btn btn-default waves-effect waves-light m-l-5 m-t-20">
                            إلغاء
                        </button>
                    </div>

                </div>
            </div><!-- end col -->

            <div class="row">

                <div class="col-lg-4">
                    <div class="card-box" style="overflow: hidden;">
                        <h4 class="header-title m-t-0 m-b-30">  الصورة   الأساسية</h4>
                        <div class="form-group <?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                            <div class="col-sm-12">
                                <input data-parsley-fileextension='jpg,png' id="image" type="file" required
                                       accept='.jpeg,.png,.jpg' name="image" class="dropify" data-max-file-size="6M"/>
                                <?php if($errors->has('image')): ?>
                                    <p class="help-block">
                                        <?php echo e($errors->first('image')); ?>

                                    </p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div><!-- end col -->

                <div class="col-md-8">
                    <div class="card-box" style="overflow: hidden;">
                        <?php for($i = 0; $i < 4; $i++): ?>
                            <div class="col-xs-3">
                                <div class="form-group">
                                    <label for="usernames">  صور  المنتج  </label>
                                    <input type="file" name="images[]" class="dropify" data-max-file-size="6M"/>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });
        $(document).on('change', '.category', function () {

            var City_id = $(this).val(),
                div = $(this).parent().parent().parent(),
                op = " ",
                showElement = div.find('.showElement');

            $.ajax({
                type: "Get",
                beforeSend: function () {
                    $('.sub_category').text(" ");
                },
                url: '<?php echo e(route('sub_categories')); ?>',
                data: {'id': City_id},
                success: function (data) {
                    var myData = data.data;

                    op += '<option  disabled selected>  إختر   الفرعي</option>';
                    for (var i = 0; i < myData.length; i++) {
                        op += '<option value="' + myData[i].id + '">' + myData[i].name + '</option>';
                    }
                    div.find('.sub_category').html(" ");
                    div.find('.sub_category').append(op);
                    showElement.delay(500).slideDown();

                }
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/products/create.blade.php ENDPATH**/ ?>