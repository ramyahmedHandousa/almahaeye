
<div>
    <section>
        <div class="container">
            <div class="sec-title">
                <h3 class="title">المنتجات</h3>
                <form class="filter">
                    <button class=" btn btn-sm form-control">
                        <i class="fa fa-minus"></i>
                    </button>
                    <div >
                        <input class="form-control me-2" name="q" wire:model.debounce.500ms="q" type="search" placeholder="Search" aria-label="Search">
                    </div>

                                    <div class="dropdown">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            الأقسام
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li>
                                                    <a class="dropdown-item" wire:click="selectCategory(<?php echo e($category->id); ?>)" href="#"><?php echo e($category->name); ?></a>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                    <div class="dropdown">
                                        <button class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                            العلامة التجارية
                                        </button>
                                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                                            <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><a class="dropdown-item" wire:click="selectBrand(<?php echo e($brand->id); ?>)" href="#"><?php echo e($brand->name); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                </form>
            </div>
            <!-- products -->
            <div class="row products">
                <!-- product -->
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2">
                        <div class="product">
                            <?php if($product->discount): ?>
                                <div class="discount-percent"><?php echo e(round($product->discount / $product->price * 100,2)); ?> <span>%</span></div>
                            <?php endif; ?>
                            <a class="wishlist add-product-to-favorite" data-id="<?php echo e($product->id); ?>" href="#">
                                <i class="fas fa-heart favorite-product-<?php echo e($product->id); ?>"></i>
                            </a>
                            <div class="product-img">
                                <img loading="lazy"  src="<?php echo e($product->getFirstMediaUrl('master_image')); ?>" alt="<?php echo e($product->name); ?>">
                            </div>
                            <div class="product-content">
                                <h4 class="product-title"><a href="<?php echo e(route('products',$product->id)); ?>"><?php echo e($product->name); ?></a></h4>
                                <div class="product-price"><span><?php echo e($product->price); ?></span> ر.س</div>

                                <div class="stars">
                                    <i class="fas fa-star yellow"></i>
                                    <i class="fas fa-star yellow"></i>
                                    <i class="fas fa-star yellow"></i>
                                    <i class="fas fa-star yellow"></i>
                                    <i class="fas fa-star"></i>
                                </div>
                                <div class="product-color">
                                    <span class="product-black"></span>
                                    <span class="product-red"></span>
                                    <span class="product-blue"></span>
                                    <span class="product-yelow"></span>
                                    <span class="product-white"></span>
                                </div>
                            </div>
                            <a class="product-basket add-to-cart" data-id="<?php echo e($product->id); ?>" href="#">
                                <i class="fas fa-plus"></i>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/livewire/products.blade.php ENDPATH**/ ?>