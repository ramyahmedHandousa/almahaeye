<?php $__env->startSection('styles'); ?>

    <style>
        .error{
            color: red;
        }
        .inputCode{
            font-size: 30px;
            color: #0a0302;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top:5%;margin-bottom: 5%">
        <h2 class="title">برجاء إدخال الباسورد الجديد </h2>
        <form class="row validation-code" action="<?php echo e(route('auth-send-new-password')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>


            <input type="hidden" value="<?php echo e($token); ?>" name="token">
            <div class="col-lg-6 form-group " style="margin-bottom: 50px;margin-top: 20px">
                <span class="label label-info">الباسورد الجديد:</span>
                <input type="password" name="password"  maxlength="20" class="form-control inputCode" placeholder="الباسورد الجديد" required>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="col-lg-6 form-group " style="margin-bottom: 50px;margin-top: 20px">
                <span class="label label-info">تأكيد الباسورد الجديد:</span>
                <input type="password" name="confirm_password"  maxlength="20" class="form-control inputCode" placeholder="تأكيد الباسورد الجديد:"  required>
                <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="col-12">
                <div class="row submit-row">
                    <div class="col-lg-3">
                        <button type="submit" class="btn the-btn-222 the-btn-2 btn-block">تاكيد</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/auth/new-password.blade.php ENDPATH**/ ?>