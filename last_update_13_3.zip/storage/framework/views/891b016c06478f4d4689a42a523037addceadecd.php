<?php $__env->startSection('title', 'المستخدمين'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- Page-Title -->



    <!-- Page-Title -->
    <div class="row">
        <div class="col-sm-12">
            <h4 class="page-title"><?php echo e($pageName); ?>  </h4>
        </div>
    </div>


    <div class="row">
        <div class="col-sm-12">
            <div class="card-box table-responsive">

                <div class="dropdown pull-right">


                </div>

                <h4 class="header-title m-t-0 m-b-30">
                    
                </h4>

                <table id="datatable-fixed-header" class="table table-striped table-bordered dt-responsive nowrap">
                    <thead>
                    <tr>
                        <th> الإسم التجاري</th>
                        <th> الإسم</th>
                        <th> رقم الهاتف</th>
                        <th>إيميل التواصل</th>
                        <th>البنك التابع له</th>
                        <th>الحي التابع له</th>
                        <th><?php echo app('translator')->get('trans.created_at'); ?></th>
                        <th><?php echo app('translator')->get('trans.options'); ?></th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($row->trade_name); ?></td>
                            <td><?php echo e($row->name); ?></td>
                            <td><?php echo e($row->phone ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->email ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->bank?->name ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->country?->name ? : 'لايوجد'); ?></td>
                            <td><?php echo e($row->created_at != ''? @$row->created_at->format('Y/m/d'): "--"); ?></td>
                            <td>

                                <a href="<?php echo e(route('vendors.show', $row->id)); ?>"
                                   data-toggle="tooltip" data-placement="top"
                                   data-original-title="تفاصيل"
                                   class="btn btn-icon btn-xs waves-effect  btn-info">
                                    <i class="fa fa-pencil"></i>
                                </a>

                                <a href="<?php echo e(route('vendors.refuse', $row->id)); ?>" title=" رفض"
                                   class="btn btn-icon btn-xs waves-effect btn-danger">
                                    <i class="fa fa-times-circle"></i>
                                </a>

                                <a href="<?php echo e(route('vendors.accepted', $row->id)); ?>" title="قبول"
                                   class="btn btn-icon btn-xs waves-effect btn-success">
                                    <i class="fa fa-check-circle"></i>
                                </a>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>
        </div><!-- end col -->
    </div>
    <!-- end row -->


<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


    <script>


    </script>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/vendors/new.blade.php ENDPATH**/ ?>