<?php $__env->startSection('title' ,'تعديل العرض'); ?>


<?php $__env->startSection('styles'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <link href="<?php echo e(request()->root()); ?>/assets/admin/plugins/bootstrap-datepicker/dist/css/bootstrap-datepicker.min.css"
          rel="stylesheet">
    <link href="<?php echo e(request()->root()); ?>/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.css"
          rel="stylesheet">


    <style>
        .bootstrap-select .dropdown-toggle .filter-option-inner-inner {
            text-align: right;
        }
        .bootstrap-select>.dropdown-toggle.bs-placeholder, .bootstrap-select>.dropdown-toggle.bs-placeholder:active, .bootstrap-select>.dropdown-toggle.bs-placeholder:focus, .bootstrap-select>.dropdown-toggle.bs-placeholder:hover {
            height: 38px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form id="storeCampaign" method="POST" action="<?php echo e(route('offers.update', $offer->id)); ?>"
          enctype="multipart/form-data"
          data-parsley-validate
          novalidate class="submission-form">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <!-- Page-Title -->
        <div class="row">
            <div class="col-lg-10 col-sm-offset-1">
                <div class="btn-group pull-right m-t-15">
                    <button type="button" class="btn btn-custom  waves-effect waves-light"
                            onclick="window.history.back();return false;"> <?php echo app('translator')->get('maincp.back'); ?><span class="m-l-5"><i
                                    class="fa fa-reply"></i></span>
                    </button>
                </div>
                <h4 class="page-title">إدارة العروض</h4>
            </div>
        </div>


        <div class="row">
            <div class="col-lg-10 col-sm-offset-1">
                <div class="card-box" style="margin-bottom: 100px">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <h2 class="header-title m-t-0 m-b-30">تعديل العروض</h2>
                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="userName">إسم المنتج*</label>
                            <h4><?php echo e($offer->name); ?></h4>













                        </div>
                    </div>


                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="discount">سعر الخصم*</label>
                            <input type="number" name="discount" value="<?php echo e($offer->discount); ?>"
                                   class="form-control"   required  placeholder="سعر الخصم..."
                            />
                            <p class="help-block" id="error_discount"></p>
                            <?php if($errors->has('discount')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('discount')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="col-xs-6">

                        <div class="form-group">
                            <label class="control-label">مدة العرض</label>
                            <div class="input-daterange input-group" id="date-range">
                                <input type="text" class="form-control" name="start_at" autocomplete="off" required
                                       data-parsley-required-message="تاريخ بداية العرض إلزامي"
                                       placeholder="تاريخ بداية العرض" value="<?php echo e(\Carbon\Carbon::parse($offer['start_at'] )->format('m/d/Y')); ?>"/>
                                <span class="input-group-addon bg-primary b-0 text-white">إلي</span>
                                <input type="text" class="form-control" name="end_at" autocomplete="off"
                                       data-parsley-required-message="تاريخ نهاية العرض إلزامي"
                                       placeholder="تاريخ نهاية العرض" value="<?php echo e(\Carbon\Carbon::parse($offer['end_at'] )->format('m/d/Y')); ?>" required/>
                            </div>

                        </div>
                    </div>


                    <div class="clearfix"></div>


                    <div class="form-group text-right m-t-20">

                        <button class="btn btn-primary waves-effect waves-light m-t-20" id="btnRegister" type="submit">
حفظ
                        </button>
                        <button onclick="window.history.back();return false;" type="reset"
                                class="btn btn-default waves-effect waves-light m-l-5 m-t-20">
                            <?php echo app('translator')->get('maincp.disable'); ?>
                        </button>
                    </div>

                </div>
            </div><!-- end col -->

        </div>


        <!-- end row -->
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script type="text/javascript"
            src="<?php echo e(request()->root()); ?>/assets/admin/js/validate-<?php echo e(config('app.locale')); ?>.js"></script>
    <script src="<?php echo e(request()->root()); ?>/assets/admin/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo e(request()->root()); ?>/assets/admin/plugins/bootstrap-daterangepicker/daterangepicker.js"></script>

    <script src="<?php echo e(request()->root()); ?>/assets/admin/plugins/bootstrap-inputmask/bootstrap-inputmask.min.js"
            type="text/javascript"></script>




    <script>
        $(document).ready(function() {
            $('.select2').select2();
        });

        jQuery('#date-range').datepicker({
            toggleActive: true,
            autoClose: true
        });


        // CKEDITOR.replace('editor1');
        // CKEDITOR.replace('editor2');

        jQuery('#date-range').datepicker({
            toggleActive: true,
            autoClose: true
        });

        //Date range picker
        $('.input-daterange-datepicker').daterangepicker({
            buttonClasses: ['btn', 'btn-sm'],
            applyClass: 'btn-default',
            cancelClass: 'btn-primary'
        });


    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/products/offers/edit.blade.php ENDPATH**/ ?>