<div class="dropdown">
    <button class="dropdown-toggle" type="button" id="dropdownMenuButton2" data-bs-toggle="dropdown"
            aria-expanded="false">
                          <span class="icon">
                            <i class="fas fa-user"></i>
                          </span>
        <?php echo \Illuminate\Support\Str::limit(auth()->user()?->name, 10, ' ...'); ?>

    </button>
    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
        <li>
            <a class="dropdown-item" href="<?php echo e(route('my-profile')); ?>">
                حسابى
            </a>
        </li>
            <a class="dropdown-item" href="<?php echo e(route('orders.index')); ?>">
                طلباتي
            </a>
        <li>

        </li>





















                <?php if(auth()->user()->type == 'vendor'): ?>
                    <li>
                            <a class="dropdown-item" href="<?php echo e(route('vendor-products.index')); ?>">
                                منتجاتى
                            </a>
                    </li>
                <?php endif; ?>

            <?php if(auth()->user()->type == 'client'): ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('addresses.index')); ?>">
                        عناوينى
                    </a>
                </li>
            <?php endif; ?>
            <?php if(auth()->user()?->is_active == 0): ?>
                <li style="background-color: #e0c057">
                    <a class="dropdown-item" href="<?php echo e(route('check-user-code')); ?>">
                    تفعيل الحساب
                    </a>
                </li>
            <?php endif; ?>
            <li>
                <a class="dropdown-item" href="<?php echo e(route('contact-us')); ?>">
                    تواصل معنا
                </a>
            </li>







            <li>
                <a class="dropdown-item" href="<?php echo e(route('global-setting','terms')); ?>">
                    الشروط والأحكام
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="<?php echo e(route('global-setting','privacy')); ?>">
                    سياسة الاسترجاع
                </a>
            </li>
            <li>
                <a class="dropdown-item" onclick="window.localStorage.clear()" href="<?php echo e(route('log-out')); ?>">
                    تسجيل الخروج
                </a>
            </li>
    </ul>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views//website/layouts/_partials/dropdown-navbar/auth.blade.php ENDPATH**/ ?>