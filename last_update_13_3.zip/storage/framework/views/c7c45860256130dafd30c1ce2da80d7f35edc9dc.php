<?php $__env->startSection('styles'); ?>

    <style>
        .error{
            color: red;
        }
        .mapSearchLocation{
            z-index: 1; position: absolute;  top: 10px !important;
            left: 197px; height: 40px;   width: 63%;   border: none;
            box-shadow: rgba(0, 0, 0, 0.3) 0px 1px 4px -1px;
            padding: 0 1em;   color: rgb(86, 86, 86);
            font-family: Roboto, Arial, sans-serif;
            user-select: none;  font-size: 18px;   margin: 10px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <section>
        <div class="container">
            <div class="sec-title">
                <h2 class="title">تسجيل تاجر جديد</h2>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <form class="row" method="post" action="<?php echo e(route('register-vendor')); ?>" enctype="multipart/form-data">

                <?php echo csrf_field(); ?>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="trade_name" value="<?php echo e(old('trade_name')); ?>" class="form-control" placeholder="الإسم التجاري" required>
                    <?php $__errorArgs = ['trade_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="first_name" value="<?php echo e(old('first_name')); ?>" class="form-control" placeholder="اسم الاول" required>
                    <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="last_name" value="<?php echo e(old('last_name')); ?>" class="form-control" placeholder="اسم الأخير" required>
                    <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="البريد الإلكترونى" required>
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="phone" value="<?php echo e(old('phone')); ?>" class="form-control" placeholder="رقم الهاتف" required>
                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-4 form-group">
                    <input type="password" name="password" class="form-control" placeholder="كلمة المرور" required>
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-4 form-group">
                    <input type="password" name="confirm_password" class="form-control" placeholder="تأكيد كلمة المرور" required>
                    <?php $__errorArgs = ['confirm_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <select class="form-select" id="country"   required>
                        <option value=''>اختار الدولة</option>
                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($country->id); ?>><?php echo e($country->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-lg-4 form-group">
                    <select class="form-select"  id="region"  required>
                        <option value=''>اختار المحافظة</option>
                    </select>
                </div>

                <div class="col-lg-4 form-group">
                    <select class="form-select" id="city" required>
                        <option value=''>اختار المدينة</option>
                    </select>
                </div>

                <div class="col-lg-4 form-group">
                    <select class="form-select" name="country_id"  id="state"  required>
                        <option value=''>اختار الحي</option>
                    </select>

                    <?php $__errorArgs = ['country_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>


                <div class="col-lg-4 form-group">
                    <select class="form-select" name="bank_id" required>
                        <option value=''>اختار البنك</option>
                        <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value=<?php echo e($bank->id); ?>><?php echo e($bank->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="iban" value="<?php echo e(old('iban')); ?>" class="form-control" placeholder=" رقم الأيبان" required>
                    <?php $__errorArgs = ['iban'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">
                    <input type="text"  name="commercial_registration" value="<?php echo e(old('commercial_registration')); ?>" class="form-control" placeholder="رقم السجل التجاري" required>
                    <?php $__errorArgs = ['commercial_registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="col-lg-4 form-group">  </div>

                <div class="col-lg-12 row" style="margin-top: 5%;margin-bottom: 5%">

                    <div class="col-lg-4 form-group">
                        <div class="row">
                            <label class="col-lg-8"  >صورة السجل التجارى</label>
                            <?php $__errorArgs = ['image_commercial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-lg-4">
                                <div class="upload-file form-group">
                                    <label >
                                        <div class="upload-icon">
                                            <img class="prev" id="image_commercial" loading="lazy"
                                                 src="<?php echo e(asset('website/templates/images/upload-to-cloud.png')); ?>">
                                        </div>
                                        <input type="file" name="image_commercial" onChange="img_record(this);" class="inputfile"
                                                 />
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4 form-group">
                        <div class="row">
                            <label class="col-lg-8">اتفاقية التسويق</label>
                            <?php $__errorArgs = ['image_marketing_agreement'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-lg-4">
                                <div class="upload-file form-group">
                                    <label >
                                        <div class="upload-icon">
                                            <img class="prev" id="image_marketing_agreement" loading="lazy"
                                                 src="<?php echo e(asset('website/templates/images/upload-to-cloud.png')); ?>">
                                        </div>
                                        <input type="file" name="image_marketing_agreement" onChange="marketing_record(this);"  class="inputfile"
                                                />
                                    </label>
                                </div>
                            </div>
                            <p>يجب تحميل الاتفاقية و توقيعها و ارفاقها مرة اخرى لإتمام التسجيل</p>
                            <a href="<?php echo e(asset('website/uploads/e-marketing.pdf')); ?>" target="_blank">تحميل اتفاقية التسويق الإلكتروني</a>
                        </div>
                    </div>

                    <div class="col-lg-4 form-group">
                        <div class="row">
                            <label for="image_service_provider" class="col-lg-8">صورة مقدم الخدمة</label>
                            <?php $__errorArgs = ['image_service_provider'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-lg-4">
                                <div class="upload-file form-group">
                                    <label>
                                        <div class="upload-icon">
                                            <img class="prev" id="image_service_provider"  loading="lazy"
                                                 src="<?php echo e(asset('website/templates/images/upload-to-cloud.png')); ?>">
                                        </div>
                                        <input type="file" name="image_service_provider" id="file-input" onChange="img_pathUrl(this);"
                                               class="inputfile"/>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>



                <div class="col-12" >
                    <div class="mb-15" >
                        <h5>اختر موقعك علي الخريطه</h5>
                        <input   id="pac-input" name="address_search" required
                                 class="controls mapSearchLocation" value="<?php echo e(old('address_search')); ?>"
                                 type="text"    placeholder="بحث"  >
                        <input type="hidden" name="latitude"  value="<?php echo e(old('latitude')); ?>" id="lat"/>
                        <input type="hidden" name="longitude" value="<?php echo e(old('longitude')); ?>" id="lng"/>
                        <input type="hidden" name="address"   value="<?php echo e(old('address')); ?>" id="address"/>
                        <div  id="googleMap" width="100%" height="300" style="height: 300px;"></div>
                        <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <div class="col-12 form-group">
                    <label class="form-check-label">
                        <input class="form-check-input" type="checkbox" value="" required>
                        أوافق على جميع الشروط والاحكام و سياسة الخصوصية
                    </label>
                </div>

                <div class="col-12">
                    <div class="row submit-row">
                        <div class="col-lg-3 order2">
                            <a class="btn btn-gray" href="<?php echo e(url('/')); ?>">إلغاء</a>
                        </div>

                        <div class="col-lg-3">
                            <button type="submit" class="btn">التالى</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script src="<?php echo e(asset('website/templates/js/mapLocation.js')); ?>"></script>

    <script defer
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDBr8fHyX4CFO0PMq4dxJlhPH8RrjXfyN8&amp;callback=initAutocomplete&libraries=places">
    </script>


    <script src="<?php echo e(asset('website/templates/js/countries.js')); ?>"></script>

    <script>
        function img_pathUrl(input) {
            $('#image_commercial')[0].src = (window.URL ? URL : webkitURL).createObjectURL(input.files[0]);
        }

        function img_record(input) {
            $('#image_commercial')[0].src = (window.URL ? URL : webkitURL).createObjectURL(input.files[0]);
        }

        function marketing_record(input) {
            $('#image_marketing_agreement')[0].src = (window.URL ? URL : webkitURL).createObjectURL(input.files[0]);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/auth/register-vendor.blade.php ENDPATH**/ ?>