<?php $__env->startSection('styles'); ?>

    <link href="/assets/admin/plugins/bootstrap-sweetalert/sweet-alert.css" rel="stylesheet"
          type="text/css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <!-- start breadcrumbs -->
    <div class="container">
        <div class="sec-title" style="margin-top: 10px;">
            <h2 class="title">بياناتي الشخصية</h2>
        </div>
        <!-- profile card -->
        <div class="profile-bg">
            <div>
                <div class="profile-img" style="border: 1px solid #DCDC;border-radius:100px;">
                    <img style="width: 100%; height: 100%;" loading="lazy"
                         src="<?php echo e(auth()->user()?->getFirstMediaUrl('master_image') ?: asset('website/templates/images/avatar.png')); ?>">
                </div>

                <div class="profile-name">
                    <h4><?php echo e(auth()->user()?->name); ?></h4>
                    <p><?php echo e(auth()->user()?->email); ?></p>
                </div>
            </div>
            <a href="<?php echo e(route('my-profile')); ?>" class="btn">تحرير الملف الشخصى</a>
        </div>
        <!-- tabs -->

        <div class="row">

            <div class="col-md-12 col-xs-12">
                <ul class="nav nav-tabs nav-tabs-profile">
                    <li class="<?php echo e(request()->route()->getName() == 'my-favorite-products.index'? "active" :""); ?>">
                        <a href="<?php echo e(route('my-favorite-products.index')); ?>">
                            <img src="<?php echo e(asset('website/azkataam/img/t1-a.png')); ?>"
                                 class="img-a mr-5">
                            <img src="<?php echo e(asset('website/azkataam/img/t1-b.png')); ?>" class="img-b mr-5">قائمة
                            المفضلة

                        </a>
                    </li>
                    <li class="<?php echo e(request()->route()->getName() == 'addresses.index'? "active" :""); ?>">
                        <a href="<?php echo e(request()->route()->getName() != 'addresses.index'? route('addresses.index') : '#'); ?>">
                            <img loading="lazy" src="<?php echo e(asset('website/azkataam/img/t3-a.png')); ?>"
                                 class="img-a mr-5">
                            <img loading="lazy" src="<?php echo e(asset('website/azkataam/img/t3-b.png')); ?>" class="img-b mr-5">
                            قائمة عناوينى</a>

                    </li>
                </ul>

                <div class="tab-content">
                    <div class="sec-title">
                        <h4 class="title">قائمة التمني</h4>
                    </div>
                    <!-- addresses -->


                        <div class="row products">
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-lg-2">
                                <div class="product">
                                    <?php if($product['discount']): ?>
                                        <div class="discount-percent"><?php echo e(round($product['discount'] / $product['price'] * 100,2)); ?> <span>%</span></div>
                                    <?php endif; ?>
                                    <a class="wishlist add-product-to-favorite" data-id="<?php echo e($product['id']); ?>" href="#">
                                        <i class="fas fa-heart colorRed favorite-product-<?php echo e($product['id']); ?>"></i>
                                    </a>
                                    <div class="product-img"><img loading="lazy" alt="image" src="<?php echo e($product['image']); ?>"></div>
                                    <div class="product-content">
                                        <h4 class="product-title">
                                            <a href="<?php echo e(route('products',$product['id'])); ?>"><?php echo e($product['name']); ?></a>
                                        </h4>
                                        <div class="product-price"><span><?php echo e($product['discount']?:$product['price']); ?></span> ر.س</div>
                                        <div class="product-color">
                                            <span class="product-black"></span>
                                            <span class="product-red"></span>
                                            <span class="product-blue"></span>
                                            <span class="product-yelow"></span>
                                            <span class="product-white"></span>
                                        </div>
                                    </div>
                                    <a class="product-basket add-to-cart" data-id="<?php echo e($product['id']); ?>"  href="#">
                                        <i class="fas fa-plus"></i>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>















                </div>
            </div>
        </div>
    </div>


    <!-- end internal-page -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/products/favorite.blade.php ENDPATH**/ ?>