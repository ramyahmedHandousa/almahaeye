
<div id="top">
    <div class="container">
        <ul>













        </ul>
        <ul>
            <li class="lang">
                <div class="dropdown">
                    <button class="dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <span class="icon">
                                <img loading="lazy"   src="<?php echo e(asset('website/templates/images/saudi-arabia.png')); ?>" alt="">
                            </span>
                        العربية
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li>
                            <a class="dropdown-item" href="#">
                                    <span class="icon">
                                        <img loading="lazy"   src="<?php echo e(asset('website/templates/images/saudi-arabia.png')); ?>" alt="">
                                    </span>
                                العربية
                            </a>
                        </li>
                        <li>
                            <a class="dropdown-item" href="#">
                                    <span class="icon">
                                        <img loading="lazy"   src="<?php echo e(asset('website/templates/images/united-states-of-america.png')); ?>" alt="">
                                    </span>
                                الإنجليزية
                            </a>
                        </li>
                    </ul>
                </div>
            </li>

            <?php if(auth()->guard()->check()): ?>
                <li class="profile-menu">
                    <?php echo $__env->make('.website.layouts._partials.dropdown-navbar.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </li>
            <?php endif; ?>

            <?php if(auth()->guard()->guest()): ?>
                <li class="profile">
                    <?php echo $__env->make('.website.layouts._partials.dropdown-navbar.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </li>
            <?php endif; ?>

        </ul>
    </div>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/_partials/navbar.blade.php ENDPATH**/ ?>