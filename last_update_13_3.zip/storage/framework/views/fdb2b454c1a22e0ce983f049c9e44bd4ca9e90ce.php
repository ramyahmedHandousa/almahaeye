<?php $__env->startSection("title", __("maincp.call_us")); ?>
<?php $__env->startSection('styles'); ?>

    <style>
        .customeStyleSocail{

            margin: 10px auto;

        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <form action="<?php echo e(route('administrator.settings.store')); ?>" data-parsley-validate="" novalidate="" method="post"
          enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <!-- Page-Title -->
        <div class="row">
            <div class="col-sm-12">
                <div class="btn-group pull-right m-t-0">
                    <div class="btn-group pull-right m-t-15">
                        <button type="button" class="btn btn-custom  waves-effect waves-light"
                                onclick="window.history.back();return false;"> <?php echo app('translator')->get('maincp.back'); ?><span class="m-l-5"><i
                                        class="fa fa-reply"></i></span>
                        </button>
                    </div>

                </div>
                <h4 class="page-title">الإعدادات العامة</h4>
            </div>
        </div>


        <div class="row">
            <div class="col-sm-12">
                <div class="card-box table-responsive  ">

                    <div class="form-group">

                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2">الفاكس </span>
                                <input class="form-control" type="text" name="fax"
                                       value="<?php echo e($setting->getBody('fax')); ?>" placeholder="0123456789"
                                       maxlength="500" >
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><?php echo app('translator')->get('maincp.e_mail'); ?> </span>
                                <input class="form-control" type="email" name="contactus_email"
                                       value="<?php echo e($setting->getBody('contactus_email')); ?>" placeholder="Example@Advertisement.sa"
                                       maxlength="500"
                                >
                            </div>
                        </div>


                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><i class="fa fa-facebook"></i></span>
                                <input type="text" class="form-control" name="faceBook"
                                       value="<?php echo e($setting->getBody('faceBook')); ?>"
                                       placeholder="<?php echo app('translator')->get('maincp.facebook'); ?> "
                                       aria-label="Recipient's username" aria- describedby="basic-addon2"
                                       maxlength="500" >
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><i class="fa fa-twitter"></i></span>
                                <input type="text" name="twitter"
                                       value="<?php echo e($setting->getBody('twitter')); ?>" class="form-control"
                                       placeholder="<?php echo app('translator')->get('maincp.twitter'); ?> "
                                       aria-label="Recipient's username" aria- describedby="basic-addon2"
                                       maxlength="500" >
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2">
                                    <i class="fa fa-whatsapp" aria-hidden="true"></i>
                                </span>
                                <input type="text" name="whatsapp"
                                       value="<?php echo e($setting->getBody('whatsapp')); ?>" class="form-control"
                                       placeholder="whatsapp " aria-label="Recipient's username" maxlength="500">
                            </div>
                        </div>

                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><i class="fa fa-instagram"></i></span>
                                <input type="text" name="instagram"
                                       value="<?php echo e($setting->getBody('instagram')); ?>" class="form-control"
                                       placeholder="<?php echo app('translator')->get('maincp.instagram'); ?>  "
                                       aria-label="Recipient's username" aria- describedby="basic-addon2"
                                       maxlength="500">
                            </div>
                        </div>
                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><i class="fa fa-snapchat"></i></span>
                                <input type="text" name="snapchat"
                                       value="<?php echo e($setting->getBody('snapchat')); ?>" class="form-control"
                                       aria-label="Recipient's username" aria- describedby="basic-addon2"
                                       maxlength="500">
                            </div>
                        </div>


                        <div class="col-lg-6 col-xs-12">
                            <div class="input-group customeStyleSocail">
                                <span class="input-group-addon" id="basic-addon2"><?php echo app('translator')->get('maincp.address'); ?> </span>
                                <input class="form-control" type="text" name="address"
                                       value="<?php echo e($setting->getBody('address')); ?>" placeholder="address"
                                       maxlength="500"
                                >
                            </div>
                        </div>

                        <div class="col-xs-12 text-right">

                            <button type="submit" class="btn btn-warning">
                               <?php echo app('translator')->get('maincp.save_data'); ?>   <i style="display: none;" id="spinnerDiv"
                                                class="fa fa-spinner fa-spin"></i>
                            </button>

                        </div>

                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">

        $("#checkbox_minimum_order").on('change', function() {
            if ($(this).is(':checked')) {
                $("#minimum_order").show();
                $(this).attr('value', 'true');
            } else {
                $("#minimum_order").hide();
                $(".minimum_order").attr('value', 0);
            }
        });

        $('form').on('submit', function (e) {
            e.preventDefault();
            var formData = new FormData(this);


            var form = $(this);
            form.parsley().validate();

            if (form.parsley().isValid()) {
                $('#spinnerDiv').show();
                $.ajax({
                    type: 'POST',
                    url: $(this).attr('action'),
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {

                        messageDisplay( 'نجاح' ,data.message )
                    },
                    error: function (data) {
                    }
                });
            }
        });

        function messageDisplay($title, $message) {
            var shortCutFunction = 'success';
            var msg = $message;
            var title = $title;
            toastr.options = {
                positionClass: 'toast-top-left',
                onclick: null
            };
            $toastlast = toastr[shortCutFunction](msg, title);
        }

    </script>
<?php $__env->stopSection(); ?>








<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/settings/contactus.blade.php ENDPATH**/ ?>