<!-- Navigation Bar-->
<header id="topnav">

    <div class="topbar-main">
        <div class="container">

            <!-- LOGO -->
            <div class="topbar-left">
                
                    
            </div>
            <!-- End Logo container-->


            <div class="menu-extras">

                <ul class="nav navbar-nav navbar-right pull-right">
                    
                    
                    
                    
                    
                    

                    <li>
                        <!-- Notification -->














                        <!-- End Notification bar -->
                    </li>


                    
                        
                           
                            
                                 
                                 
                        

                        

                            
                            
                            

                            
                                
                                    
                                        
                                            
                                        
                                    
                                
                            


                        
                    

                    <li class="dropdown user-box">
                        <a href="" class="dropdown-toggle waves-effect waves-light profile " data-toggle="dropdown"
                           aria-expanded="true">

                            <img src="<?php echo e(auth()->user()?->getFirstMediaUrl()?:asset('/default.png')); ?>"
                                     alt="user-img" class="img-circle user-img">

                        </a>

                        <ul class="dropdown-menu">
                            <li><a href="<?php echo e(route('helpAdmin.edit', auth()->user()?->id)); ?>"><i
                                            class="ti-user m-r-5"></i><?php echo app('translator')->get('maincp.personal_page'); ?></a></li>




                            <li>
                                <a href="<?php echo e(route('administrator.logout')); ?>"
                                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    <i class="ti-power-off m-r-5"></i><?php echo app('translator')->get('maincp.log_out'); ?>
                                </a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <div class="menu-item">
                    <!-- Mobile menu toggle-->
                    <a class="navbar-toggle">
                        <div class="lines">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                    </a>
                    <!-- End mobile menu toggle-->
                </div>
            </div>

        </div>
    </div>

    <form id="logout-form" action="<?php echo e(route('administrator.logout')); ?>" method="POST"
          style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>

    <div class="navbar-custom">
        <div class="container">
            <div id="navigation">
                <!-- Navigation Menu-->
                <ul class="navigation-menu" style="    font-size: 14px;">

                    <li>
                        <a href="<?php echo e(route('admin.home')); ?>"><i class="zmdi zmdi-view-dashboard"></i>
                            <span> الرئيسية </span> </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('users.index')); ?>"><i class="zmdi zmdi-view-dashboard"></i>
                            <span> المستخدمين </span> </a>
                    </li>
                    <li class="has-submenu">
                        <a href="#"><i class="zmdi zmdi-layers"></i><span>التجار</span>
                        </a>
                        <ul class="submenu ">
                             <li><a href="<?php echo e(route('vendors.index').'?type=new'); ?>"> التجار الجدد</a></li>
                            <li><a href="<?php echo e(route('vendors.index')); ?>">التجار الحالين</a></li>
                            <li><a href="<?php echo e(route('change_profile')); ?>">طلبات التغير  </a></li>
                        </ul>
                    </li>

                    <li class="has-submenu">
                        <a href="#"><i class="zmdi zmdi-layers"></i><span>  الإضافات الأساسية </span>
                        </a>
                        <ul class="submenu ">

                            <li><a href="<?php echo e(route('categories.index')); ?>"> الأقسام الرئيسية</a></li>
                            <li><a href="<?php echo e(route('categories.index').'?type=sub'); ?>"> الأقسام الفرعية</a></li>
                            <li><a href="<?php echo e(route('countries.index')); ?>"> الدول  </a></li>
                            <li><a href="<?php echo e(route('countries.index').'?type=sub'); ?>"> المحافظات</a></li>
                            <li><a href="<?php echo e(route('countries.index').'?type=subSub'); ?>"> المدن</a></li>
                            <li><a href="<?php echo e(route('countries.index').'?type=subSubSub'); ?>"> الأحياء</a></li>
                            <li><a href="<?php echo e(route('banks.index')); ?>"> البنوك</a></li>
                            <li><a href="<?php echo e(route('promo_codes.index')); ?>"> أكواد الخصم</a></li>
                            <li><a href="<?php echo e(route('shipping.index')); ?>">شركات الشحن</a></li>
                        </ul>
                    </li>
                    <li class="has-submenu">
                        <a href="#"><i class="zmdi zmdi-layers"></i><span>  الإضافات الخاصة بالمنتج </span>
                        </a>
                        <ul class="submenu ">
                            <li><a href="<?php echo e(route('brands.index')); ?>"> الماركات</a></li>
                            <li><a href="<?php echo e(route('ages.index')); ?>">   السن</a></li>
                            <li><a href="<?php echo e(route('colors.index')); ?>?type=frame_colors">   لون الإطار</a></li>
                            <li><a href="<?php echo e(route('colors.index')); ?>?type=lens_colors">      لون العدسة</a></li>
                            <li><a href="<?php echo e(route('frame_materials.index')); ?>">        خامة الإطار</a></li>
                            <li><a href="<?php echo e(route('frame_shaps.index')); ?>">        شكل الإطار</a></li>
                            <li><a href="<?php echo e(route('product_types.index')); ?>">        نوع النظارة  </a></li>
                            <li><a href="<?php echo e(route('products.index')); ?>">المنتجات</a></li>
                        </ul>
                    </li>
                        <li>
                            <a href="<?php echo e(route('offers.index')); ?>">العروض</a>
                        </li>
                    <li class="has-submenu">
                        <a href="#"><i class="zmdi zmdi-layers"></i><span>الإعدادت العامة</span>
                        </a>
                        <ul class="submenu ">
                            <li><a href="<?php echo e(route('settings.contactus')); ?>"> بيانات التواصل </a></li>
                            <li><a href="<?php echo e(route('settings.global')); ?>">   بيانات الموقع</a></li>
                        </ul>
                    </li>

                    <li>
                        <a href="<?php echo e(route('contact_us_inbox.index')); ?>">تواصل معنا</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('public_notification')); ?>">الإشعارات الجماعية</a>
                    </li>


                </ul>
                <!-- End navigation menu  -->
            </div>
        </div>
    </div>

</header>
<!-- End Navigation Bar-->


<div class="wrapper">
    <div class="container">
<?php /**PATH /home/euindemo/public_html/resources/views/admin/layouts/_partials/header.blade.php ENDPATH**/ ?>