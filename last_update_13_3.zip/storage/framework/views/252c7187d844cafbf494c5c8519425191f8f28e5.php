<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="cart">
    <!-- start internal-page -->
    <div class="container">

        <div class="row">
            <!-- cart products -->

                <?php echo $__env->make('website.cart.sections.list-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('website.cart.sections.list-address', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('website.cart.sections.list-shipping', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('website.cart.sections.order-info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </div>
    <!-- end internal-page -->
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>


    <script>

    </script>

    <script>



    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/cart/index.blade.php ENDPATH**/ ?>