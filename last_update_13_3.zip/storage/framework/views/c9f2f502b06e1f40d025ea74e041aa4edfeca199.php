<?php $__env->startSection('styles'); ?>
    <style>
        .wrapper-page {
            margin: 3% auto;
            position: relative;
            width: 420px;
        }
        .error_validation{
          font-size: 13px;
          color: #ff5757;
        }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>




    <div class="m-t-40 card-box">
        <div class="text-center">
            <h4 class="text-uppercase font-bold m-b-0">  <?php echo app('translator')->get('institutioncp.login'); ?>  </h4>
        </div>
        <div class="panel-body">



<?php if(session()->has('errorSuspend')): ?>
 <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong> <?php echo e(session()->get('errorSuspend')); ?></strong>
                </div>


                <?php else: ?>

            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong> <?php echo e(session()->get('error')); ?></strong>
                </div>
            <?php endif; ?>
  <?php endif; ?>

            <form class="form-horizontal m-t-20" method="POST" action="<?php echo e(route('admin.login')); ?>">
                <?php echo e(csrf_field()); ?>




                <div class="form-group">
                    <div class="col-xs-12">
                        <input id="email" type="text" class="form-control" required name="email"
                               value="<?php echo e(old('email')); ?>"  autofocus
                               placeholder="<?php echo app('translator')->get('institutioncp.user_or_email'); ?> ...">

                        <?php if($errors->has('email')): ?>
                            <span class="help-block error_validation" style=" font-size: 13px;color: #ff5757;">
                                <strong><?php echo e($errors->first('email')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-xs-12">
                        <input id="password" type="password" class="form-control"
                               name="password"  required
                               placeholder="  <?php echo app('translator')->get('institutioncp.password'); ?>...">

                        <?php if($errors->has('password')): ?>
                            <span class="help-block error_validation" style=" font-size: 13px;color: #ff5757;">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                        <?php endif; ?>
                    </div>
                </div>















                <div class="form-group text-center m-t-30">
                    <div class="col-xs-12">
                        <button class="btn btn-custom btn-bordred btn-block waves-effect waves-light" type="submit">
                            <?php echo app('translator')->get('institutioncp.login'); ?>
                        </button>
                    </div>
                </div>









            </form>

        </div>
    </div>
    <!-- end card-box-->




<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>