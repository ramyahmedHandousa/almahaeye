
<!-- start slider -->
<?php echo $__env->make('website.layouts.sections.slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end slider -->

<!-- start categories section -->
<?php echo $__env->make('website.layouts.sections.main-categories',['mainCategories' => $mainCategories ?? []], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end categories section -->



<?php echo $__env->make('website.layouts.sections.products-most-order',['productsMostOrder' => $productsMostOrder ?? []], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php echo $__env->make('website.layouts.sections.filter-categories-have-products',['categoriesHaveProducts' => $categoriesHaveProducts ?? [] ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/euindemo/public_html/resources/views/website/categories/all.blade.php ENDPATH**/ ?>