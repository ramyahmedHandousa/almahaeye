
<div class="slider">
    <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <a href="#">
                    <img loading="lazy" src="<?php echo e(asset('website/templates/images/banner.jpg')); ?>" alt="banner">
                </a>
            </div>
            <div class="carousel-item">
                <a href="#">
                    <img loading="lazy" src="<?php echo e(asset('website/templates/images/banner.jpg')); ?>" alt="banner">
                </a>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls"
                data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/sections/slider.blade.php ENDPATH**/ ?>