<div class="title cart-list-address" style="display: none">اختيار عنوان</div>

<div class="col-lg-8 cart-list-address"  style="display: none">
    <div class="box">
        <div >
            <div class="table-responsive">
                <table class="table">
                    <tbody>
                    <?php if(auth()->user()?->address): ?>
                        <?php $__currentLoopData = auth()->user()?->address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input class="form-check-input cart-choose-address" name="address" type="radio" value="<?php echo e($address->id); ?>">
                                </td>
                                <td><?php echo e($address->address); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <a href="<?php echo e(route('addresses.create')); ?>" target="_blank"><h5 class="sub-title">أضف عنوان جديد</h5></a>

        </div>
    </div>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/cart/sections/list-address.blade.php ENDPATH**/ ?>