<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>عين المها</title>
    <meta name="description" content="">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('website.layouts._partials.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        .colorRed{
            color: red !important;
        }
    </style>
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
<!-- start top -->
<?php echo $__env->make('website.layouts._partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end top -->
<!-- start header-2 -->
<?php echo $__env->make('website.layouts.sections.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end header -->

<div style="margin-top: 2%;margin-bottom: 5%">
    <?php echo $__env->yieldContent('content'); ?>
</div>


<!-- end products -->
<!-- start subscription box -->
<?php echo $__env->make('website.layouts._partials.subscription-box', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end subscribe -->

<!-- start footer -->
<?php echo $__env->make('website.layouts._partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end footer -->

<?php echo $__env->make('website.layouts._partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('scripts'); ?>

<?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/master.blade.php ENDPATH**/ ?>