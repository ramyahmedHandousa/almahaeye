<?php $__env->startSection('title' ,  __('maincp.notification')); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page-Title -->
    <form method="POST" action="<?php echo e(route('send_public_notification')); ?>" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-sm-12">
                <div class="btn-group pull-right m-t-15">
                    <button type="button" class="btn btn-custom  waves-effect waves-light"
                            onclick="window.history.back();return false;"> <?php echo app('translator')->get('maincp.back'); ?><span class="m-l-5"><i
                                class="fa fa-reply"></i></span>
                    </button>
                </div>
                <h4 class="page-title"><?php echo app('translator')->get('maincp.notification'); ?>  </h4>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12">
                <div class="card-box">
                    <h4 class="header-title m-t-0 m-b-30"><?php echo app('translator')->get('maincp.notification'); ?> </h4>
                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="userName"> العنوان بالعربية* </label>
                            <input type="text" name="title"  value="<?php echo e(old('title')); ?>" class="form-control" required
                                   placeholder=" العنوان بالعربية "
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message=" العنوان بالعربية إلزامي"
                                   data-parsley-maxlength="200"
                                   data-parsley-maxlength-message=" أقصى عدد الحروف المسموح بها هى (200) حرف"
                                   data-parsley-minlength="3"
                                   data-parsley-minlength-message="اقل عدد حروف مسموح به هو 3 حروف"/>
                            <?php if($errors->has('title')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('title')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xs-6">
                        <div class="form-group">
                            <label for="userName"> العنوان بالانجليزية* </label>
                            <input type="text" name="title_en"  value="<?php echo e(old('title_en')); ?>" class="form-control" required
                                   placeholder=" العنوان بالانجليزية "
                                   data-parsley-trigger="keyup"
                                   data-parsley-required-message=" العنوان بالانجليزية إلزامي"
                                   data-parsley-maxlength="200"
                                   data-parsley-maxlength-message=" أقصى عدد الحروف المسموح بها هى (200) حرف"
                                   data-parsley-minlength="3"
                                   data-parsley-minlength-message="اقل عدد حروف مسموح به هو 3 حروف"/>
                            <?php if($errors->has('title_en')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('title_en')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>



                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="userName"> الرسالة بالعربية* </label>
                            <textarea name="body"  class="form-control" required
                                      placeholder=" الرسالة بالعربية "
                                      data-parsley-trigger="keyup"
                                      data-parsley-required-message=" الرسالة بالعربية إلزامي"
                                      data-parsley-maxlength="250"
                                      data-parsley-maxlength-message=" أقصى عدد الحروف المسموح بها هى (250) حرف"
                                      data-parsley-minlength="3"
                                      data-parsley-minlength-message="اقل عدد حروف مسموح به هو 3 حروف"><?php echo e(old('body')); ?></textarea>
                            <?php if($errors->has('body')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('body')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-xs-12">
                        <div class="form-group">
                            <label for="userName"> الرسالة بالانجليزية* </label>
                            <textarea name="body_en"  class="form-control" required
                                      placeholder=" الرسالة بالانجليزية "
                                      data-parsley-trigger="keyup"
                                      data-parsley-required-message=" الرسالة بالانجليزية إلزامي"
                                      data-parsley-maxlength="250"
                                      data-parsley-maxlength-message=" أقصى عدد الحروف المسموح بها هى (250) حرف"
                                      data-parsley-minlength="3"
                                      data-parsley-minlength-message="اقل عدد حروف مسموح به هو 3 حروف"><?php echo e(old('body_en')); ?></textarea>
                            <?php if($errors->has('body_en')): ?>
                                <p class="help-block validationStyle">
                                    <?php echo e($errors->first('body_en')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    </div>


                    <div class="col-xs-12">
                        <div class="form-group text-right m-b-0 ">
                            <button class="btn btn-primary waves-effect waves-light m-t-20" type="submit">ارسال</button>
                        </div>
                    </div>

                    <div class="clearfix"></div>
                </div>
            </div><!-- end col -->
        </div>
    </form>
    <!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            var table = $('#datatable-fixed-header-notify').DataTable({
                fixedHeader: true,
                "order": [[4, "desc"]],
                // columnDefs: [{orderable: false, targets: [0]}],
                "language": {
                    "lengthMenu": "<?php echo app('translator')->get('maincp.show'); ?> _MENU_ <?php echo app('translator')->get('maincp.perpage'); ?>",
                    "info": "<?php echo app('translator')->get('maincp.show'); ?> <?php echo app('translator')->get('maincp.perpage'); ?> _PAGE_ <?php echo app('translator')->get('maincp.from'); ?>_PAGES_",
                    "infoEmpty": "<?php echo app('translator')->get('maincp.no_recorded_data_available'); ?>",
                    "infoFiltered": "(<?php echo app('translator')->get('maincp.filter_from_max_total'); ?> _MAX_)",
                    "paginate": {
                        "first": "<?php echo app('translator')->get('maincp.first'); ?>",
                        "last": "<?php echo app('translator')->get('maincp.last'); ?>",
                        "next": "<?php echo app('translator')->get('maincp.next'); ?>",
                        "previous": "<?php echo app('translator')->get('maincp.previous'); ?>"
                    },
                    "search": "<?php echo app('translator')->get('maincp.search'); ?>:",
                    "zeroRecords": "<?php echo app('translator')->get('maincp.no_recorded_data_available'); ?>",
                },
            });
        });
    </script>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/notifications/create.blade.php ENDPATH**/ ?>