<?php $__env->startSection('title', __('maincp.users_manager')); ?>


<?php $__env->startSection('styles'); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <form   method="POST" action="<?php echo e(route('promo_codes.update', $promoCode->id)); ?>" enctype="multipart/form-data"
            data-parsley-validate novalidate>
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('PUT')); ?>


    <!-- Page-Title -->
        <div class="row">
            <div class="col-lg-12  ">
                <div class="btn-group pull-right m-t-15">
                    <button type="button" class="btn btn-custom  waves-effect waves-light"
                            onclick="window.history.back();return false;"> رجوع <span class="m-l-5"><i
                                class="fa fa-reply"></i></span>
                    </button>
                </div>
                <h4 class="page-title">إدارة <?php echo e($pageName); ?></h4>
            </div>
        </div>

        <div class="row">
            <div class="col-lg-12  ">
                <div class="card-box">


                    <h4 class="header-title m-t-0 m-b-30"> تعديل <?php echo e($pageName); ?></h4>

                    <div class="row">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <div class="col-xs-4">
                            <div class="form-group">
                                <label for="times"> الكود للمستخدم </label>
                                <input type="number" name="code" min=1 maxlength="10" oninput="validity.valid||(value='');"
                                       class="form-control number " value="<?php echo e($promoCode->code); ?>" required />
                                <p class="help-block" id="error_times"></p>
                            </div>
                        </div>

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label for="times">عدد مرات  إستخدام الكود للمستخدم </label>
                                    <input type="number" name="time_used" value="<?php echo e($promoCode->time_used); ?>" min=1 maxlength="6" oninput="validity.valid||(value='');"
                                           class="form-control    number " required />
                                    <p class="help-block" id="error_times"></p>
                                </div>
                            </div>

                            <div class="col-xs-4">
                                <div class="form-group">
                                    <label>نسبة خصم إستخدام الكود للمستخدم   </label>

                                    <div class="input-group bootstrap-touchspin">
                                        <input class="form-control  " min="1" value="<?php echo e($promoCode->percentage); ?>" type="text" required
                                               name="percentage"  placeholder="نسبة خصم إستخدام الكود للمستخدم"  >

                                        <span class="input-group-addon bootstrap-touchspin-postfix">%</span>
                                    </div>
                                </div>
                            </div>


                            <div class="col-xs-6">
                            <div class="form-group">
                                <label for="date">تاريخ بداية إستخدام الكود </label>
                                <div class="input-group">
                                    <input type="text" name="start_at"  class="form-control  datepicker  "
                                           value="<?php echo e($promoCode->start_at->format("Y-m-d")); ?>" required />
                                    <span class="input-group-addon bg-primary b-0 text-white"><i class="ti-calendar"></i></span>
                                    <p class="help-block" id="error_date"></p>
                                </div>
                            </div>
                        </div>


                        <div class="col-xs-6">
                            <div class="form-group">
                                <label for="end_at">تاريخ نهاية إستخدام الكود </label>
                                <div class="input-group">
                                    <input type="text" name="end_at"  value="<?php echo e($promoCode->end_at->format("Y-m-d")); ?>"   class="form-control  datepicker  " required />
                                    <span class="input-group-addon bg-primary b-0 text-white"><i class="ti-calendar"></i></span>
                                    <p class="help-block" id="error_end_at"></p>
                                </div>
                            </div>
                        </div>



                    </div>


                    <div class="form-group text-right m-t-20">
                        <button   class="btn btn-warning waves-effect waves-light m-t-20" type="submit">
                            <?php echo app('translator')->get('maincp.save_data'); ?>
                        </button>
                        <button onclick="window.history.back();return false;" type="reset"
                                class="btn btn-default waves-effect waves-light m-l-5 m-t-20">
                            <?php echo app('translator')->get('maincp.disable'); ?>
                        </button>
                    </div>

                </div>
            </div><!-- end col -->


        </div>
        <!-- end row -->
    </form>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('scripts'); ?>


    <script type="text/javascript"
            src="<?php echo e(request()->root()); ?>/assets/admin/js/validate-<?php echo e(config('app.locale')); ?>.js"></script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/promo_codes/edit.blade.php ENDPATH**/ ?>