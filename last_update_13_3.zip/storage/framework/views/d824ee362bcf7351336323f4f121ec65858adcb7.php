<?php $__env->startSection('title' ,__('maincp.use_Treaty')); ?>
<?php $__env->startSection('styles'); ?>



<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="se-pre-con"></div>

    <form action="<?php echo e(route('administrator.settings.store')); ?>" data-parsley-validate="" novalidate="" method="post"
          enctype="multipart/form-data">

    <?php echo e(csrf_field()); ?>


        <div class="row">
            <div class="col-sm-8 col-sm-offset-2" >
                <div class="btn-group pull-right m-t-15">
                </div>

            </div>
        </div>

        <div class="row">
            <div class="col-sm-12" >
                <div class="card-box">




                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-6">
                            <div class="form-group">
                                <label for="terms_website"> سياسة الخصوصية - <?php echo e($value); ?> </label>
                                <textarea  rows="10" class="form-control msg_body" name="privacy_<?php echo e($value); ?>"><?php echo e($setting->getBody('privacy_'.$value)); ?></textarea>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="about_app_desc">محتوي الموقع باللغة - <?php echo e($value); ?> </label>
                                    <textarea  rows="10" class="form-control msg_body" name="about_app_<?php echo e($value); ?>"><?php echo e($setting->getBody('about_app_'.$value)); ?></textarea>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="about"> عن المطور باللغة - <?php echo e($value); ?> </label>
                                    <textarea   rows="10" class="form-control msg_body" name="developer_<?php echo e($value); ?>"><?php echo e($setting->getBody('developer_'.$value)); ?></textarea>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="terms_website">شروط الاستخدام - <?php echo e($value); ?> </label>
                                    <textarea   rows="10" class="form-control msg_body" name="terms_<?php echo e($value); ?>"><?php echo e($setting->getBody('terms_'.$value)); ?></textarea>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $locale => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-6">
                                <div class="form-group">
                                    <label for="terms_website">وصف الموقع - <?php echo e($value); ?> </label>
                                    <textarea  rows="10" class="form-control msg_body" name="website_description_<?php echo e($value); ?>"><?php echo e($setting->getBody('website_description_'.$value)); ?></textarea>
                                </div>
                            </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <div class="form-group text-right m-t-20">
                        <button class="btn btn-primary waves-effect waves-light m-t-20" type="submit" id="btnSubmit">
                            <?php echo app('translator')->get('maincp.save_data'); ?>
                        </button>
                        <button onclick="window.history.back();return false;" type="reset"
                                class="btn btn-default waves-effect waves-light m-l-5 m-t-20">
                            <?php echo app('translator')->get('maincp.disable'); ?>
                        </button>
                    </div>

                </div>
            </div>
        </div>
        <!-- end row -->
    </form>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>


    <script type="text/javascript">

        $('form').on('submit', function (e) {
            e.preventDefault();

            $("#btnSubmit").html("جاري حفظ البيانات...");

            for (instance in CKEDITOR.instances)
                CKEDITOR.instances[instance].updateElement();


            var formData = new FormData(this);


            var form = $(this);
            form.parsley().validate();

            if (form.parsley().isValid()) {
                $.ajax({
                    type: 'POST',
                    url: $(this).attr('action'),
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    success: function (data) {


                        if (data.status == true) {
                            $("#btnSubmit").html("حفظ البيانات");
                            var shortCutFunction = 'success';

                            var msg = data.message;
                            var title = 'نجاح';
                            toastr.options = {
                                maxOpened: 1,
                                preventDuplicates: 1,
                                positionClass: 'toast-top-left',
                                onclick: null
                            };
                            var $toast = toastr[shortCutFunction](msg, title); // Wire up an event handler to a button in the toast, if it exists
                            $toastlast = $toast;
                        }

                    },
                    error: function (data) {

                    }
                });
            } else {
                $("#btnSubmit").html("حفظ البيانات");
            }

        });
    </script>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/admin/settings/global.blade.php ENDPATH**/ ?>