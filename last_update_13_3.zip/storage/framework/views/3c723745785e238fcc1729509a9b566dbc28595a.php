<?php $__env->startSection('styles'); ?>

    <style>
        .error{
            color: red;
        }
        .inputCode{
            font-size: 30px;
            color: #0a0302;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="container" style="margin-top:10px;">
        <h2 class="title">تأكيد رقم الجوال</h2>

        <form class="row validation-code" action="<?php echo e(route('auth.activation.account')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <input type="hidden" value="<?php echo e(request('token')); ?>" name="token">

                <div class="col-lg-2 form-group ">
                </div>

                <div class="col-lg-2 form-group ">
                    <input type="text" name="code1"  maxlength="1" class="form-control inputCode" required>
                    <?php $__errorArgs = ['code1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 form-group">
                    <input type="text"  name="code2" maxlength="1"  class="form-control inputCode" required>
                    <?php $__errorArgs = ['code2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 form-group">
                    <input type="text"  name="code3" maxlength="1"  class="form-control inputCode" required>
                    <?php $__errorArgs = ['code3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="col-lg-2 form-group">
                    <input type="text"  name="code4" maxlength="1"  class="form-control inputCode" required>
                    <?php $__errorArgs = ['code4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>



            <div class="form-group" style="margin-bottom: 40px">
            </div>
            <div class="sub-title">ارسال كود التفعيل خلال <span id="time">3</span> دقائق!
                <span class="edit" id="active">
                    <a href="<?php echo e(route('auth.resend.code')); ?>">إعادة ارسال كود التفعيل</a></span>
            </div>
            <div class="col-12">
                <div class="row submit-row">
                    <div class="col-lg-3 order2">
                        <a class="btn btn-gray" href="<?php echo e(url('/')); ?>">رجوع</a>
                    </div>
                    <div class="col-lg-3">
                        
                        <button type="submit" class="btn the-btn-222 the-btn-2 btn-block">تاكيد</button>
                    </div>
                </div>
            </div>
        </form>
    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('scripts'); ?>

    <script>
        var start;
        var timer_is_on = 0;

        function startTimer(duration, display) {
            var timer = duration, minutes, seconds;
            start = setInterval(function () {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);

                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;

                display.textContent = minutes + ":" + seconds;
                timer_is_on = 1;
                $('#active').hide();
                if (--timer < 0) {
                    timer = duration;
                }
                if (timer == 0) {
                    clearTimeout(start);
                    $('#active').show();
                }
            }, 1000);
        }

        window.onload = function () {
            var fiveMinutes = 60 * 3,
                display = document.querySelector('#time');
            startTimer(fiveMinutes, display);
        };

        function stop() {
            clearTimeout(start);
            $('#active').show();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/auth/check-code.blade.php ENDPATH**/ ?>