
<section>
    <div class="container">
        <div class="row">
            <div class="sec-title">
                <h3 class="title">منتجات اكثر طلب</h3>




            </div>
        </div>
        <div class="row products">
            <?php $__currentLoopData = $productsMostOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2">
                <div class="product">
                    <a class="wishlist add-product-to-favorite" data-id="<?php echo e($product->id); ?>" href="#">
                        <i class="fas fa-heart favorite-product-<?php echo e($product->id); ?>" ></i>
                    </a>
                    <div class="product-img">
                        <img loading="lazy"  src="<?php echo e($product->getFirstMediaUrl('master_image')); ?>" alt="<?php echo e($product->name); ?>">
                    </div>
                    <div class="product-content">
                        <h4 class="product-title">
                            <a href="<?php echo e(route('products',$product->id)); ?>"><?php echo e($product->name); ?></a>
                        </h4>
                        <div class="product-price">
                            <span><?php echo e($product->price); ?></span> ر.س
                        </div>

                        <div class="stars">
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star yellow"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <div class="product-color">
                            <span class="product-black"></span>
                            <span class="product-red"></span>
                            <span class="product-blue"></span>
                            <span class="product-yelow"></span>
                            <span class="product-white"></span>
                        </div>
                    </div>
                    <a class="product-basket add-to-cart" data-id="<?php echo e($product->id); ?>"  href="#">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/sections/products-most-order.blade.php ENDPATH**/ ?>