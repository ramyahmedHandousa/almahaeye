<?php $__env->startSection('content'); ?>


    <section>
        <!-- start internal-page -->
        <div class="container">
            <h2 class="title"><?php echo e($text); ?></h2>
            <p> <?php echo e($body); ?> </p>
        </div>
        <!-- end internal-page -->
    </section>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('website.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/euindemo/public_html/resources/views/website/setting/global.blade.php ENDPATH**/ ?>