<div class="title cart-list-shipping" style="display: none"> اختيار شركة الشحن</div>

<div class="col-lg-8 cart-list-shipping" style="display: none">
    <div class="box">
        <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ship): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="form-group">
            <label class="form-check-label">
                <input class="form-check-input cart-choose-shipping" name="Shipping" type="radio" value="<?php echo e($ship->id); ?>">
                <?php echo e($ship->name); ?> -
                ( تكلفة:<?php echo e($ship->price); ?> ر.س)
                 -
                 (دفع عند الإستلام :<?php echo e($ship->pay == 1 ? ' يوجد ' : ' لا يوجد  '); ?>  )
            </label>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/cart/sections/list-shipping.blade.php ENDPATH**/ ?>