
<section class="categories">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $mainCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4">
                    <div class="category">
                        <a href="<?php echo e(route('categories',$category->id)); ?>">
                            <img loading="lazy"  src="<?php echo e($category->getFirstMediaUrl('master_image')); ?>" alt="<?php echo e($category->name); ?>">
                            <span class="name"><?php echo e($category->name); ?></span>
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH /home/euindemo/public_html/resources/views/website/layouts/sections/main-categories.blade.php ENDPATH**/ ?>