
<div class="col-lg-6">
    <button type="button" class="btn btn" data-bs-toggle="modal" data-bs-target="#exampleModal-<?php echo e($order->id); ?>">
        إنهاء الطلب
    </button>
</div>

<div class="modal fade" id="exampleModal-<?php echo e($order->id); ?>" data-bs-backdrop="static" tabindex="-1"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content">
            <form method="post" action="<?php echo e(route('finish-order',$order->id)); ?>" >
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <h5 class="title">هل انت متأكد من إنهاء الطلب</h5>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-gray" data-bs-dismiss="modal">الغاء</button>
                    <button type="submit" class="btn ">نعم</button>
                </div>
            </form>

        </div>
    </div>
</div>
<?php /**PATH /home/euindemo/public_html/resources/views/website/orders/actions/finish-order.blade.php ENDPATH**/ ?>