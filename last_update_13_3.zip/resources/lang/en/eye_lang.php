<?php

return [

    'order' => [
        'orders'                    => 'orders',
        'new order'                 => 'new order',
        'preparation order'         => 'The order has been preparation ',
        'accepted order'            => 'The order has been accepted ',
        'finish order'              => 'The order has been finish ',
        'refuse_by_user order'      => 'The order has been canceled',
        'refuse_by_vendor order'    => 'The order has been canceled',
    ]
];
