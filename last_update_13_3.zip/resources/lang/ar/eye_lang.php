<?php

return [

    'order' => [
        'orders'                    => 'الطلبات',
        'new order'                 => 'طلب جديد',
        'preparation order'         => 'جاري تجهيز الطلب',
        'accepted order'            => 'تم قبول الطلب',
        'finish order'              => 'تم إنتهاء الطلب',
        'refuse_by_user order'      => 'تم إلغاء الطلب',
        'refuse_by_vendor order'    => 'تم إلغاء الطلب',
    ]
];
