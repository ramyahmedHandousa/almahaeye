@extends('website.layouts.master')
@section('styles')



@endsection
@section('content')

    <livewire:products />


@endsection
@section('scripts')


@endsection
