
<link rel="icon" type="image/png" href="{{asset('website/templates/images/favicon.png')}}">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet"
      integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
<link rel="stylesheet" href="{{asset('website/templates/css/fontawesome.css')}}">
<!-- start slick slider -->
<link rel="stylesheet" href="{{asset('website/templates/css/slick.css')}}">
<!-- end slick slider -->
<link rel="stylesheet" href="{{asset('website/templates/css/bootstrap-slider.min.css')}}">
<link rel="stylesheet" href="{{asset('website/templates/css/style.css')}}">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css">
